
#ifndef EXPLOSION_IS_DEF
#define EXPLOSION_IS_DEF


void animation_explosion_add (int x, int y, int size);

  
#endif
