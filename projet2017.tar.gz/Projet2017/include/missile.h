
#ifndef MISSILE_IS_DEF
#define MISSILE_IS_DEF


void animation_missile_add (dynamic_object_t *obj, int shot, int y_offset);


#endif
