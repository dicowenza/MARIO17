
#ifndef TANK_IS_DEF
#define TANK_IS_DEF


void animation_tank_add (int x, int y, int from_file,
			 int direction, int speed, int proj, unsigned size);


#endif
