
#ifndef TEXT_IS_DEF
#define TEXT_IS_DEF


void animation_text_add (int x, int y, sprite_t *sp);


#endif
