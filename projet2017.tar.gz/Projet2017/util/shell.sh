#!/bin/sh

echo maputil "$@"

exit 0
